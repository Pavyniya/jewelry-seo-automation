-- Jewelry SEO Database Backup
-- Generated: 2025-09-25T09:59:33.172Z
-- Tables: products, optimization_versions, content_reviews, optimization_jobs

-- Table: products
CREATE TABLE products (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        vendor TEXT,
        product_type TEXT,
        tags TEXT,
        variants TEXT,
        images TEXT,
        seo_title TEXT,
        seo_description TEXT,
        optimized_description TEXT,
        optimization_status TEXT NOT NULL DEFAULT 'pending',
        last_optimized DATETIME,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        shopify_data TEXT,
        sync_version INTEGER DEFAULT 1,
        UNIQUE(id)
      );



-- Table: optimization_versions
CREATE TABLE optimization_versions (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        version INTEGER NOT NULL,
        original_title TEXT NOT NULL,
        original_description TEXT,
        original_seo_title TEXT,
        original_seo_description TEXT,
        optimized_title TEXT NOT NULL,
        optimized_description TEXT,
        optimized_seo_title TEXT,
        optimized_seo_description TEXT,
        ai_provider TEXT NOT NULL,
        tokens_used INTEGER DEFAULT 0,
        cost REAL DEFAULT 0.0,
        response_time INTEGER DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE
      );



-- Table: content_reviews
CREATE TABLE content_reviews (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        version_id TEXT NOT NULL,
        reviewer TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected', 'changes_requested')),
        feedback TEXT,
        approved_at DATETIME,
        created_at DATETIME NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE,
        FOREIGN KEY (version_id) REFERENCES optimization_versions (id) ON DELETE CASCADE
      );



-- Table: optimization_jobs
CREATE TABLE optimization_jobs (
        id TEXT PRIMARY KEY,
        product_id TEXT NOT NULL,
        job_type TEXT NOT NULL CHECK (job_type IN ('seo_optimization', 'content_generation', 'bulk_optimization')),
        status TEXT NOT NULL DEFAULT 'pending',
        provider_id TEXT,
        priority INTEGER DEFAULT 5,
        retry_count INTEGER DEFAULT 0,
        max_retries INTEGER DEFAULT 3,
        error_message TEXT,
        started_at DATETIME,
        completed_at DATETIME,
        created_at DATETIME NOT NULL,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE CASCADE,
        FOREIGN KEY (provider_id) REFERENCES ai_providers (id) ON DELETE SET NULL
      );



